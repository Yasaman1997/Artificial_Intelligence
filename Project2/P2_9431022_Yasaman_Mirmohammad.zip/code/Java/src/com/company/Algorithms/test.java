package com.company.Algorithms;

public class test {
}
