package com.company.Algorithms.SA;

import java.util.ArrayList;

public class SimulatedAnnealing {

    float HeatingRate = (float) 0.003;

    public SimulatedAnnealing(float coolingRate) {


    }
}

